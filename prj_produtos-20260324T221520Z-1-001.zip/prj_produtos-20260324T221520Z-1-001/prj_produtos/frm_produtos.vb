﻿Imports System.IO
Imports System.Globalization

Public Class Form1

    Private Function CaminhoImagemPadrao() As String
        Return Application.StartupPath & "\fotos\sem_foto.png"
    End Function

    Private Function CarregarImagemSemTravar(caminho As String) As Image
        Try
            If Not File.Exists(caminho) Then Return Nothing

            Dim bytes() As Byte = File.ReadAllBytes(caminho)
            Dim ms As New MemoryStream(bytes)
            Return Image.FromStream(ms)
        Catch
            Return Nothing
        End Try
    End Function

    Private Function TextoSQL(texto As String) As String
        Return Replace(Trim(texto), "'", "''")
    End Function

    Private Function ValorDecimal(texto As String) As Decimal
        Dim valor As Decimal = 0
        Decimal.TryParse(texto.Replace(".", ","), valor)
        Return valor
    End Function

    Private Function ValorInteiro(texto As String) As Integer
        Dim valor As Integer = 0
        Integer.TryParse(texto, valor)
        Return valor
    End Function

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Conecta_banco()

        diretorio = CaminhoImagemPadrao()

        If File.Exists(diretorio) Then
            img_foto.Image = CarregarImagemSemTravar(diretorio)
        Else
            img_foto.Image = Nothing
        End If

        ConfigurarGrid()
        Limpar_campos()
        Carregar_produtos()
    End Sub

    Sub Limpar_campos()
        Try
            txt_descricao.Clear()
            txt_marca.Clear()
            txt_quantidade.Clear()
            txt_preco_custo.Clear()
            txt_preco_venda.Clear()
            txt_pesquisa.Clear()

            dtp_data_lote.Value = Now
            ts_campo_pesquisa.Text = ""

            diretorio = CaminhoImagemPadrao()

            If File.Exists(diretorio) Then
                img_foto.Image = CarregarImagemSemTravar(diretorio)
            Else
                img_foto.Image = Nothing
            End If

            txt_descricao.Focus()
        Catch ex As Exception
            MsgBox("Erro ao limpar campos: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Erro")
        End Try
    End Sub

    Sub ConfigurarGrid()
        Try
            dgv_produtos.AllowUserToAddRows = False
            dgv_produtos.AllowUserToDeleteRows = False
            dgv_produtos.ReadOnly = True
            dgv_produtos.SelectionMode = DataGridViewSelectionMode.FullRowSelect
            dgv_produtos.MultiSelect = False
            dgv_produtos.Rows.Clear()
            dgv_produtos.RowTemplate.Height = 60

            If dgv_produtos.Columns.Contains("col_foto") Then
                DirectCast(dgv_produtos.Columns("col_foto"), DataGridViewImageColumn).ImageLayout = DataGridViewImageCellLayout.Zoom
            End If

        Catch ex As Exception
            MsgBox("Erro ao configurar grid: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Erro")
        End Try
    End Sub

    Sub Carregar_produtos(Optional termo As String = "")
        Try
            dgv_produtos.Rows.Clear()

            termo = TextoSQL(termo)

            sql = "SELECT id, descricao_produto, marca_fabricante, quantidade_disponivel, preco_custo, preco_venda, " &
                  "(preco_venda - preco_custo) AS margem_lucro, foto_produto " &
                  "FROM produtos "

            If termo <> "" Then
                sql &= "WHERE descricao_produto LIKE '%" & termo & "%' " &
                       "OR marca_fabricante LIKE '%" & termo & "%' "
            End If

            sql &= "ORDER BY descricao_produto"

            rs = db.Execute(sql)

            Do While Not rs.EOF

                Dim caminhoFoto As String = ""
                Dim fotoProduto As Image = Nothing

                If Not IsDBNull(rs.Fields("foto_produto").Value) Then
                    caminhoFoto = rs.Fields("foto_produto").Value.ToString()
                End If

                If caminhoFoto <> "" AndAlso File.Exists(caminhoFoto) Then
                    fotoProduto = CarregarImagemSemTravar(caminhoFoto)
                ElseIf File.Exists(CaminhoImagemPadrao()) Then
                    fotoProduto = CarregarImagemSemTravar(CaminhoImagemPadrao())
                End If

                ' AJUSTE A ORDEM AQUI CONFORME AS COLUNAS DO SEU DGV
                dgv_produtos.Rows.Add(
                    rs.Fields("descricao_produto").Value.ToString(),
                    rs.Fields("marca_fabricante").Value.ToString(),
                    rs.Fields("quantidade_disponivel").Value.ToString(),
                    FormatNumber(CDec(rs.Fields("preco_venda").Value), 2),
                    FormatNumber(CDec(rs.Fields("margem_lucro").Value), 2),
                    fotoProduto
                )

                rs.MoveNext()
            Loop

        Catch ex As Exception
            MsgBox("Erro ao carregar produtos: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Erro")
        End Try
    End Sub

    Private Sub SelecionarFoto()
        Try
            Dim abrir As New OpenFileDialog
            abrir.Title = "Selecionar foto do produto"
            abrir.Filter = "Arquivos de Imagem|*.jpg;*.jpeg;*.png;*.bmp"

            If abrir.ShowDialog() = DialogResult.OK Then
                diretorio = abrir.FileName
                img_foto.Image = CarregarImagemSemTravar(diretorio)
            End If
        Catch ex As Exception
            MsgBox("Erro ao carregar foto: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Erro")
        End Try
    End Sub

    Private Sub img_foto_Click(sender As Object, e As EventArgs) Handles img_foto.Click
        SelecionarFoto()
    End Sub

    Private Sub btn_limpar_Click(sender As Object, e As EventArgs) Handles btn_limpar.Click
        Limpar_campos()
        Carregar_produtos()
    End Sub

    Private Sub ts_campo_pesquisa_KeyDown(sender As Object, e As KeyEventArgs) Handles ts_campo_pesquisa.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True
            Carregar_produtos(ts_campo_pesquisa.Text)
        End If
    End Sub

    Private Sub txt_pesquisa_TextChanged(sender As Object, e As EventArgs) Handles txt_pesquisa.TextChanged
        Carregar_produtos(txt_pesquisa.Text)
    End Sub

    Private Sub btn_salvar_Click(sender As Object, e As EventArgs) Handles btn_salvar.Click
        Try
            If Trim(txt_descricao.Text) = "" OrElse
               Trim(txt_marca.Text) = "" OrElse
               Trim(txt_quantidade.Text) = "" OrElse
               Trim(txt_preco_custo.Text) = "" OrElse
               Trim(txt_preco_venda.Text) = "" Then

                MsgBox("Preencha os campos obrigatórios.", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Aviso")
                Exit Sub
            End If

            Dim descricao As String = TextoSQL(txt_descricao.Text)
            Dim marca As String = TextoSQL(txt_marca.Text)
            Dim quantidade As Integer = ValorInteiro(txt_quantidade.Text)
            Dim precoCusto As Decimal = ValorDecimal(txt_preco_custo.Text)
            Dim precoVenda As Decimal = ValorDecimal(txt_preco_venda.Text)
            Dim foto As String = TextoSQL(diretorio)
            Dim dataLote As String = Format(dtp_data_lote.Value, "yyyy-MM-dd")

            If quantidade <= 0 Then
                MsgBox("Informe uma quantidade válida.", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Aviso")
                Exit Sub
            End If

            If precoCusto < 0 OrElse precoVenda < 0 Then
                MsgBox("Informe preços válidos.", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Aviso")
                Exit Sub
            End If

            sql = "INSERT INTO produtos (" &
                  "descricao_produto, data_lote, marca_fabricante, quantidade_disponivel, preco_custo, preco_venda, foto_produto" &
                  ") VALUES (" &
                  "'" & descricao & "'," &
                  "'" & dataLote & "'," &
                  "'" & marca & "'," &
                  quantidade & "," &
                  Replace(precoCusto.ToString(CultureInfo.InvariantCulture), ",", ".") & "," &
                  Replace(precoVenda.ToString(CultureInfo.InvariantCulture), ",", ".") & "," &
                  "'" & foto & "')"

            db.Execute(sql)

            MsgBox("Produto salvo com sucesso.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Aviso")

            Carregar_produtos()
            Limpar_campos()

        Catch ex As Exception
            MsgBox("Erro ao salvar produto: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Erro")
        End Try
    End Sub

    Private Sub dgv_produtos_DataError(sender As Object, e As DataGridViewDataErrorEventArgs) Handles dgv_produtos.DataError
        e.ThrowException = False
        MsgBox("Erro ao exibir dados no DataGridView.", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Aviso")
    End Sub

    Private Sub ToolStripLabel2_Click(sender As Object, e As EventArgs) Handles pesquisador.Click
        Try
            Carregar_produtos(ts_campo_pesquisa.Text.Trim)
        Catch ex As Exception
            MsgBox("Erro ao pesquisar: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Erro")
        End Try
    End Sub
End Class