﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txt_descricao = New System.Windows.Forms.TextBox()
        Me.dtp_data_lote = New System.Windows.Forms.DateTimePicker()
        Me.img_foto = New System.Windows.Forms.PictureBox()
        Me.dgv_produtos = New System.Windows.Forms.DataGridView()
        Me.col_categoria = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_marca = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_quantidade = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_preco_venda = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_margem = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ts_campo_pesquisa = New System.Windows.Forms.ToolStripComboBox()
        Me.pesquisador = New System.Windows.Forms.ToolStripLabel()
        Me.btn_salvar = New System.Windows.Forms.ToolStripButton()
        Me.txt_preco_custo = New System.Windows.Forms.TextBox()
        Me.txt_quantidade = New System.Windows.Forms.TextBox()
        Me.txt_marca = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txt_pesquisa = New System.Windows.Forms.TextBox()
        Me.txt_preco_venda = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btn_limpar = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        CType(Me.img_foto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_produtos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(114, 87)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(55, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Descrição"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(438, 87)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(30, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Data"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(291, 89)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(37, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Marca"
        '
        'txt_descricao
        '
        Me.txt_descricao.Location = New System.Drawing.Point(117, 103)
        Me.txt_descricao.Name = "txt_descricao"
        Me.txt_descricao.Size = New System.Drawing.Size(100, 20)
        Me.txt_descricao.TabIndex = 3
        '
        'dtp_data_lote
        '
        Me.dtp_data_lote.Location = New System.Drawing.Point(441, 103)
        Me.dtp_data_lote.Name = "dtp_data_lote"
        Me.dtp_data_lote.Size = New System.Drawing.Size(200, 20)
        Me.dtp_data_lote.TabIndex = 4
        Me.dtp_data_lote.Value = New Date(2026, 3, 24, 0, 0, 0, 0)
        '
        'img_foto
        '
        Me.img_foto.Image = CType(resources.GetObject("img_foto.Image"), System.Drawing.Image)
        Me.img_foto.Location = New System.Drawing.Point(790, 48)
        Me.img_foto.Name = "img_foto"
        Me.img_foto.Size = New System.Drawing.Size(322, 174)
        Me.img_foto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.img_foto.TabIndex = 6
        Me.img_foto.TabStop = False
        '
        'dgv_produtos
        '
        Me.dgv_produtos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgv_produtos.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgv_produtos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_produtos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.col_categoria, Me.col_marca, Me.col_quantidade, Me.col_preco_venda, Me.col_margem})
        Me.dgv_produtos.Location = New System.Drawing.Point(60, 329)
        Me.dgv_produtos.Name = "dgv_produtos"
        Me.dgv_produtos.ReadOnly = True
        Me.dgv_produtos.Size = New System.Drawing.Size(703, 179)
        Me.dgv_produtos.TabIndex = 8
        '
        'col_categoria
        '
        Me.col_categoria.HeaderText = "Categoria"
        Me.col_categoria.Name = "col_categoria"
        Me.col_categoria.ReadOnly = True
        Me.col_categoria.Width = 77
        '
        'col_marca
        '
        Me.col_marca.HeaderText = "Marca / Fabricante"
        Me.col_marca.Name = "col_marca"
        Me.col_marca.ReadOnly = True
        Me.col_marca.Width = 113
        '
        'col_quantidade
        '
        Me.col_quantidade.HeaderText = "Quantidade Disponível"
        Me.col_quantidade.Name = "col_quantidade"
        Me.col_quantidade.ReadOnly = True
        Me.col_quantidade.Width = 129
        '
        'col_preco_venda
        '
        Me.col_preco_venda.HeaderText = "Preço de Venda"
        Me.col_preco_venda.Name = "col_preco_venda"
        Me.col_preco_venda.ReadOnly = True
        '
        'col_margem
        '
        Me.col_margem.HeaderText = "Margem do Lucro"
        Me.col_margem.Name = "col_margem"
        Me.col_margem.ReadOnly = True
        Me.col_margem.Width = 81
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ts_campo_pesquisa, Me.pesquisador, Me.btn_salvar})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(1182, 25)
        Me.ToolStrip1.TabIndex = 9
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ts_campo_pesquisa
        '
        Me.ts_campo_pesquisa.Name = "ts_campo_pesquisa"
        Me.ts_campo_pesquisa.Size = New System.Drawing.Size(121, 25)
        '
        'pesquisador
        '
        Me.pesquisador.Name = "pesquisador"
        Me.pesquisador.Size = New System.Drawing.Size(53, 22)
        Me.pesquisador.Text = "Pesquisa"
        '
        'btn_salvar
        '
        Me.btn_salvar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btn_salvar.Image = CType(resources.GetObject("btn_salvar.Image"), System.Drawing.Image)
        Me.btn_salvar.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btn_salvar.Name = "btn_salvar"
        Me.btn_salvar.Size = New System.Drawing.Size(23, 22)
        Me.btn_salvar.Text = "ToolStripButton1"
        '
        'txt_preco_custo
        '
        Me.txt_preco_custo.Location = New System.Drawing.Point(294, 163)
        Me.txt_preco_custo.Name = "txt_preco_custo"
        Me.txt_preco_custo.Size = New System.Drawing.Size(100, 20)
        Me.txt_preco_custo.TabIndex = 14
        '
        'txt_quantidade
        '
        Me.txt_quantidade.Location = New System.Drawing.Point(117, 163)
        Me.txt_quantidade.Name = "txt_quantidade"
        Me.txt_quantidade.Size = New System.Drawing.Size(100, 20)
        Me.txt_quantidade.TabIndex = 17
        '
        'txt_marca
        '
        Me.txt_marca.Location = New System.Drawing.Point(294, 103)
        Me.txt_marca.Name = "txt_marca"
        Me.txt_marca.Size = New System.Drawing.Size(100, 20)
        Me.txt_marca.TabIndex = 18
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(291, 147)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 13)
        Me.Label4.TabIndex = 19
        Me.Label4.Text = "Preço custo"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(114, 147)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(62, 13)
        Me.Label5.TabIndex = 20
        Me.Label5.Text = "Quantidade"
        '
        'txt_pesquisa
        '
        Me.txt_pesquisa.Location = New System.Drawing.Point(294, 223)
        Me.txt_pesquisa.Name = "txt_pesquisa"
        Me.txt_pesquisa.Size = New System.Drawing.Size(100, 20)
        Me.txt_pesquisa.TabIndex = 26
        '
        'txt_preco_venda
        '
        Me.txt_preco_venda.Location = New System.Drawing.Point(117, 223)
        Me.txt_preco_venda.Name = "txt_preco_venda"
        Me.txt_preco_venda.Size = New System.Drawing.Size(100, 20)
        Me.txt_preco_venda.TabIndex = 23
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(291, 209)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(50, 13)
        Me.Label8.TabIndex = 22
        Me.Label8.Text = "Pesquisa"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(114, 207)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(69, 13)
        Me.Label9.TabIndex = 21
        Me.Label9.Text = "Preço Venda"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(114, 297)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(72, 13)
        Me.Label6.TabIndex = 27
        Me.Label6.Text = "Exibir Produto"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(901, 278)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(83, 13)
        Me.Label7.TabIndex = 28
        Me.Label7.Text = "Foto do Produto"
        '
        'btn_limpar
        '
        Me.btn_limpar.Location = New System.Drawing.Point(1057, 299)
        Me.btn_limpar.Name = "btn_limpar"
        Me.btn_limpar.Size = New System.Drawing.Size(75, 23)
        Me.btn_limpar.TabIndex = 29
        Me.btn_limpar.Text = "limpar"
        Me.btn_limpar.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(57, 42)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(377, 24)
        Me.Label10.TabIndex = 32
        Me.Label10.Text = "Cadastrador de Produtos da empresa Prime"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.CornflowerBlue
        Me.ClientSize = New System.Drawing.Size(1182, 687)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.btn_limpar)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txt_pesquisa)
        Me.Controls.Add(Me.txt_preco_venda)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txt_marca)
        Me.Controls.Add(Me.txt_quantidade)
        Me.Controls.Add(Me.txt_preco_custo)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.dgv_produtos)
        Me.Controls.Add(Me.img_foto)
        Me.Controls.Add(Me.dtp_data_lote)
        Me.Controls.Add(Me.txt_descricao)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "x'"
        CType(Me.img_foto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_produtos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txt_descricao As TextBox
    Friend WithEvents dtp_data_lote As DateTimePicker
    Friend WithEvents img_foto As PictureBox
    Friend WithEvents dgv_produtos As DataGridView
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents txt_preco_custo As TextBox
    Friend WithEvents txt_quantidade As TextBox
    Friend WithEvents txt_marca As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txt_pesquisa As TextBox
    Friend WithEvents txt_preco_venda As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents ts_campo_pesquisa As ToolStripComboBox
    Friend WithEvents pesquisador As ToolStripLabel
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents btn_limpar As Button
    Friend WithEvents btn_salvar As ToolStripButton
    Friend WithEvents Label10 As Label
    Friend WithEvents col_categoria As DataGridViewTextBoxColumn
    Friend WithEvents col_marca As DataGridViewTextBoxColumn
    Friend WithEvents col_quantidade As DataGridViewTextBoxColumn
    Friend WithEvents col_preco_venda As DataGridViewTextBoxColumn
    Friend WithEvents col_margem As DataGridViewTextBoxColumn
End Class
