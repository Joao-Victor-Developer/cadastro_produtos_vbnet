﻿Module Module1
    Public db As New ADODB.Connection
    Public rs As New ADODB.Recordset
    Public sql As String
    Public diretorio As String
    Public cont As Integer

    Sub Conecta_banco()
        Try
            If db.State = 1 Then db.Close()
            db.Open("Provider=SQLOLEDB;Data Source=LAB5-17;Initial Catalog=cadastro_produtos;trusted_connection=yes;")
            MsgBox("Conexão OK", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Aviso")
        Catch ex As Exception
            MsgBox("Erro ao conectar com o banco", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Erro")
        End Try
    End Sub
End Module